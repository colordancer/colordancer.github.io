#define ACTION_BLOCK	1
#define ACTION_UNBLOCK	2
#define MAX_POLICY_COUNT 	10
#define MAX_ARR_COUNT       61//(10 * 6 +1)
#define P_UDP		IPPROTO_UDP
#define P_TCP		IPPROTO_TCP
#define P_ICMP		IPPROTO_ICMP
#define P_ALLP		-1

static unsigned int sz_policies[MAX_ARR_COUNT] = {0};
/*
{
	{srcip,srcport,desip,desport,protocal,action}
	....
}
sz_policies[MAX_POLICY_COUNT-1][0] = policyCount;
*/

static int policyCount = 0;
