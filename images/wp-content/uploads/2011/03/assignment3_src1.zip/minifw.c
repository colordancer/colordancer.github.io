#include <linux/kernel.h>
#include <linux/module.h>

#include <linux/proc_fs.h>
#include <linux/string.h>

#include <linux/netfilter.h>
#include <linux/netfilter_ipv4.h>
#include <linux/skbuff.h>
#include <linux/tcp.h>
#include <linux/ip.h>

#include "minifw_common.h"

MODULE_LICENSE("GPL");

static struct proc_dir_entry *proc_entry;
static struct nf_hook_ops nfho;

unsigned int hook_func(unsigned int hooknum, struct sk_buff* skb, const struct net_device* in, const struct net_device* out, int(*okfn)(struct sk_buff*))
{
    if (!skb)
        return NF_ACCEPT;

   	//get skb value
	struct iphdr* pIph = (struct iphdr *)skb_network_header(skb);
	unsigned int srcIp = pIph->saddr;
	unsigned int desIp = pIph->daddr;
	unsigned int protocol = pIph->protocol;
	//struct tcphdr* pTcph=(struct tcphdr*)(sb->data+(sb->nh.iph->ihl*4));//old version
	struct tcphdr* pTcph = (struct tcphdr *)skb_transport_header(skb);
	unsigned int srcPort = pTcph->source;
	unsigned int desPort = pTcph->dest;

	printk("minifw: Received ");
	switch(protocol)
	{
		case P_UDP:
			printk("UDP");break;
		case P_TCP:
			printk("TCP");break;
		case P_ICMP:
			printk("ICMP");break;
		default:
			printk("Other");break;
	}
	
	printk(" packet from %d.%d.%d.%d:%d to %d.%d.%d.%d:%d",
			srcIp&0x000000FF,
			(srcIp&0x0000FF00)>>8,
			(srcIp&0x00FF0000)>>16,
			(srcIp&0xFF000000)>>24,
			((srcPort&0xFF00)>>8|(srcPort&0x00FF)<<8),
			desIp&0x000000FF,
			(desIp&0x0000FF00)>>8,
			(desIp&0x00FF0000)>>16,
			(desIp&0xFF000000)>>24,
			((desPort&0xFF00)>>8|(desPort&0x00FF)<<8)				
			);

	//find skb value in policy or not
	int i = 0;
	for (; i/6 < sz_policies[MAX_ARR_COUNT - 1]; i+=6)
	{
		if ( sz_policies[i+5] == ACTION_BLOCK )
		{
			if ( sz_policies[i+4] == protocol || sz_policies[i+4] == P_ALLP)
			{
				if ( ( (srcIp == sz_policies[i+0] || sz_policies[i+0] == 0) && (srcPort == sz_policies[i+1] || sz_policies[i+1] == 0) ) ||
					 ( (desIp == sz_policies[i+2] || sz_policies[i+2] == 0) && (desPort == sz_policies[i+3] || sz_policies[i+3] == 0) ) )
				{
					printk(" - Action: BLOCK\n");
					return NF_DROP;
				}
			}
		}	
	}

	printk(" - Action: UNBLOCK\n");
	return NF_ACCEPT;
}



ssize_t minifw_write( struct file *filp, const char __user *buff, unsigned long len, void *data )
{       
    if (copy_from_user( sz_policies, buff, len )) {
        return -EFAULT;
    }
        
    printk("minifw: Write ok. Policy count:%d\n", sz_policies[MAX_ARR_COUNT-1]);

    return len;
}

int minifw_read( char *buff, char **start, off_t off, int count, int *eof, void *data )
{
    if (off > 0)
    {
        return 0;
    }
    memcpy(buff,sz_policies, sizeof(sz_policies));
    printk("minifw: Read ok. Policy count:%d\n", sz_policies[MAX_ARR_COUNT-1]);
    return sizeof(sz_policies);
}

int minifw_init()
{
	int ret = 0;
	proc_entry = create_proc_entry( "minifw", 0644, NULL );
    if (proc_entry == NULL) {
		ret = -ENOMEM;
		printk(KERN_INFO "minifw: Couldn't create proc entry.\n");
    } else {
		proc_entry->read_proc = minifw_read;
		proc_entry->write_proc = minifw_write;
		printk(KERN_INFO "minifw: Module loaded.\n");
		
		nfho.hook=hook_func;	
		nfho.hooknum=NF_INET_PRE_ROUTING;	
		nfho.pf=PF_INET;	
		nfho.priority=NF_IP_PRI_FIRST;
		
		nf_register_hook(&nfho);
    }

    printk("minifw: Loading of module successful.\n");
	
	return ret;
}

void minifw_cleanup()
{	
	remove_proc_entry("fortune", NULL);
	nf_unregister_hook(&nfho);
	printk("minifw: Removal of module successful.\n");
	return;
}

module_init( minifw_init );
module_exit( minifw_cleanup);
