#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <netinet/in.h>

#include "minifw_common.h"

void displayPolicy()
{
	int i = 0;
	printf("Policy count: %d\n",policyCount);
	for (; i/6 < policyCount; i+=6)
	{
		printf("Policy %d: ",i/6+1);
		//action
		if (sz_policies[i+5] == ACTION_BLOCK)
			printf("Block ");
		else
			printf("Unblock ");

		//protocol
		switch(sz_policies[i+4])
		{
			case P_UDP:
				printf("UDP");break;
			case P_TCP:
				printf("TCP");break;
			case P_ICMP:
				printf("ICMP");break;
			case P_ALLP:
				printf("ALL");break;
			default:
				printf("Unknown");break;
		}

		printf(" packets from ");					

		//source ip
		if (sz_policies[i] == 0)
			printf("[all ip]");
		else
			printf("%d.%d.%d.%d",sz_policies[i]&0x000000FF,(sz_policies[i]&0x0000FF00)>>8,	(sz_policies[i]&0x00FF0000)>>16,
				(sz_policies[i]&0xFF000000)>>24);
	
		printf(":");

		//source port
		if (sz_policies[i+1] == 0)
			printf("[all ports]");
		else
			printf("%d",((sz_policies[i+1]&0xFF00)>>8|(sz_policies[i+1]&0x00FF)<<8));

		printf(" to ");

		//des ip
		if (sz_policies[i+2] == 0)
			printf("[all ip]");
		else
			printf("%d.%d.%d.%d",sz_policies[i+2]&0x000000FF,(sz_policies[i+2]&0x0000FF00)>>8,	(sz_policies[i+2]&0x00FF0000)>>16,
				(sz_policies[i+2]&0xFF000000)>>24);

		printf(":");

		//des port
		if (sz_policies[i+3] == 0)
			printf("[all ports]");
		else
			printf("%d",((sz_policies[i+3]&0xFF00)>>8|(sz_policies[i+3]&0x00FF)<<8));

		printf("\n");
	}

}

void comments()
{
	printf ("Example:\nminifw_console.o -a BLOCK -s 127.0.0.1 -i 17664 -d 127.0.0.1 -o 84 -p ALL\n");
	printf("-a: action\n");
	printf("-s: from ip\n");
	printf("-i: from port\n");
	printf("-d: destination ip\n");
	printf("-o: destination port\n");
	printf("-p: protocol\n");
	printf("-l: display all policies\n");
	printf("Notice: If you want to BLOCK/UNBLOCK all IP or all ports, please type 0\n");
}

//minifw.o -a BLOCK -s 127.0.0.1 -i 1111 -d 123.123.123.123 -o 1111 -p ALL
int main(int argc, char* argv[])
{
	int protocalFlag 	= 0;
	int srcIpFlag 		= 0;
	int desIpFlag		= 0;
	int srcPortFlag 	= 0;
	int desPortFlag		= 0;
	int actionFlag 		= 0;
	int listFlag		= 0;
	char *protocalVal 	= NULL;
	char *srcIpVal		= NULL;
	char *desIpVal		= NULL;
	char *srcPortVal	= NULL;
	char *desPortVal	= NULL;
	char *actionVal		= NULL;
	
    //read from /proc
    FILE* f = fopen("/proc/minifw","r+");
	if (f)
	{
		//fgets(sz_policies,MAX_ARR_COUNT+1,f);
		if (fread(sz_policies,sizeof(sz_policies),1,f) > 0)
		{
			policyCount = sz_policies[MAX_ARR_COUNT-1];
			printf("Read policy ok! Policy count: %d\n",policyCount);
		}
		fclose(f);	
	}
	else
	{
		printf("Open /proc/minifw/ failed\n");
		return 0;
	}

    //read input
	int c;
	while ((c = getopt (argc, argv, "a:s:i:d:o:p:l")) != -1)
	{
        switch (c)
			{
			case 'a':
				actionFlag = 1;
				actionVal  = optarg;
				break;
			case 's':
				srcIpFlag = 1;
				srcIpVal  = optarg;
				break;
			case 'i':
				srcPortFlag = 1;
				srcPortVal  = optarg;
				break;
			case 'd':
				desIpFlag	= 1;
				desIpVal	= optarg;
				break;
			case 'o':
				desPortFlag	= 1;
				desPortVal	= optarg;
				break;
			case 'p':
				protocalFlag= 1;
				protocalVal = optarg;
				break;
			case 'l':
				listFlag = 1;
				displayPolicy();
				break;
			case '?':
			default:
				comments();
				return;	
           }
	}

    if (!actionFlag && !srcIpFlag && !srcPortFlag && !desIpFlag && !desPortFlag && !protocalFlag)
    {
    	if (!listFlag)
    	{
			printf ("Format error!\n");
    		comments();
    	}
        return;
    }

	if (policyCount >= MAX_POLICY_COUNT)
    {
        printf ("Max policies already: %d\n",MAX_POLICY_COUNT);
		return 0;
    }

	//set policy value
	int srcIp,srcPort,desIp,desPort;
	srcIp = srcPort = desIp = desPort = 0;
	if (srcIpFlag)
		srcIp = inet_addr(srcIpVal);
	if (srcPortFlag)
		srcPort = htons(atoi(srcPortVal));
	if (desIpFlag)
		desIp = inet_addr(desIpVal);
	if (desPortFlag)
		desPort = htons(atoi(desPortVal));
		
	int protocal = P_ALLP;
	if (!strcmp(protocalVal,"UDP"))
		protocal = P_UDP;
	else if (!strcmp(protocalVal,"TCP"))
		protocal = P_TCP;
	else if (!strcmp(protocalVal,"ICMP"))
		protocal = P_ICMP;
	else if (!strcmp(protocalVal,"ALL"))
		protocal = P_ALLP;

	int action = ACTION_UNBLOCK;//unblock
	if (!strcmp(actionVal,"BLOCK"))
		action = ACTION_BLOCK;

	//check policy exists
	int exist = 0;
	int i = 0;
	for (; i/6 < policyCount ; i+=6)
	{
		if ( sz_policies[i] == srcIp &&
			sz_policies[i+1] == srcPort &&
			sz_policies[i+2] == desIp &&
			sz_policies[i+3] == desPort &&
			sz_policies[i+4] == protocal )
		{
			//if ip and port are the same, only action not the same
			//just update the action, do not add into the policy
			//if action also the same, return
			if (sz_policies[i+5] == action)
			{
				exist = 1;
				printf("Policy already exists!\n");
				return;
			}
			else
			{
				//update action
				sz_policies[i+5] = action;
				break;
			}
		}
	}

	//add policy
	if ( !exist)
	{
		sz_policies[policyCount*6] = srcIp;
		sz_policies[policyCount*6+1] = srcPort;
		sz_policies[policyCount*6+2] = desIp;
		sz_policies[policyCount*6+3] = desPort;
		sz_policies[policyCount*6+4] = protocal;
		sz_policies[policyCount*6+5] = action;
		
		policyCount++;
        sz_policies[MAX_ARR_COUNT-1] = policyCount;       
	}
	

    //write /proc
	f = fopen("/proc/minifw","r+");
	if (f)
	{
		fwrite(sz_policies,sizeof(sz_policies),1,f);
		fclose(f);
		printf("Policy add successfully!\n");
	}
	else
	{
		printf("Open /proc/minifw/ failed\n");
	}
	
	return 0;
}
